#include<stdio.h>
#include<stdlib.h>

main()
{
	int i,even=0,odd=0,num;
	
	FILE* fp=fopen("EvenOdd.txt","w");
	if(fp==NULL)
	{
		printf("Error\n");
	}
	else
	{
		printf("Enter a number\nTerminate by -1\n");
		scanf("%d",&num);
		while(num!=-1)
		{
			fprintf(fp,"%d\n",num);
			printf("Enter a number\nTerminate by -1\n");
			scanf("%d",&num);
		}
	}
	
	fclose(fp);	
	
	fp=fopen("EvenOdd.txt","r");
	
	if(fp==NULL)
	{
		printf("Error\n");
	}
	else
	{
		fscanf(fp,"%d",&num);
		while(!feof(fp))
		{
			if(num%2==0)
			{
				even++;
			}
			if(num%2!=0)
			{
				odd++;
			}
			fscanf(fp,"%d",&num);
		}
	}
	
	fclose(fp);
	
	printf("No. of even numbers: %d\nNo. of odd numbers: %d\n",even,odd);
}
