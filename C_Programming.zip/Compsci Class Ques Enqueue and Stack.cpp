#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define length 99

int top=-1;
int tail=-1;

char pop(char stack[])
{
	char value;
	if(top==-1)
	{
		printf("Stack Empty\n");
	}
	else
	{
		value=stack[top];
		top=top-1;
	}
	return value;
}

void enqueue(char queue[],char elem,int size)
{
	
	if(tail==size)
	{
		printf("Stack full\n");
	}
	else
	{
		tail++;
		queue[tail]=elem;
	}
}

main()
{
	char word[length],wordpop[length+1]={},letter;
	int i,len;
	
	printf("Enter a word\n");
	gets(word);
	len=strlen(word);
	top=len;

	for(i=0;i<=len;i++)
	{
		letter=pop(word);
		if(letter!='\0')
		{
			enqueue(wordpop,letter,len);
		}
	}
	

	if(strcmp(wordpop,word)==0)
	{
		printf("Palindrome\n");
	}
	else
	{
		printf("Not a Palindrome\n");
	}
	
}

