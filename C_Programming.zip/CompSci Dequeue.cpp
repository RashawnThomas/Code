#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#define length 4

int tail=-1;

int dequeue(int queue[])
{
	int i,element;
	if (tail==-1) 
	{
		printf("Queue is empty\n");
	}
	else
	{
		element=queue[0];//make element the head 
		for(i=0;i<length;i++)
		{
			queue[i]=queue[i+1];
		}
	}
	tail=tail-1;
	return element;
}
