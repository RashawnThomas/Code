#include<stdio.h>
#include<stdlib.h>
main()
{
	float target;
	float donation;
	float total=0;
	int count=0;
	
	FILE* F1;
	FILE* F2;
	
	F1=fopen("Donations.txt","r");
	if(F1==NULL)
	{
		printf("Error\n");
	} 
	else
	{
		fscanf(F1,"%f",&target);
		fscanf(F1,"%f",&donation);
		
		while(donation!=-1)
		{
			total=total+donation;
			count=count+1;
			fscanf(F1,"%f",&donation);	
		}
	}
	printf("%.2f %d",total,count);
	fclose(F1);
	
	F2=fopen("Funds.txt","w");
	if(F2==NULL)
	{
		printf("Error\n");
	}
	else
	{
		fprintf(F2,"%.2f",total);
		fprintf(F2,"%d",count);
	}
	fclose(F2);
}
