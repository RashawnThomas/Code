#include<stdio.h>
#include<stdlib.h>
#define size 10
main()
{
	struct item{
		char name[50];
		float price;
		char supplier[50];
	};
	
	struct item object[size];
	int i;
	float min=9999.00,max=0.00;
	char minsupplier[50],maxsupplier[50];
	
	for(i=0;i<size;i++)
	{
		printf("Enter name of item\n");
		scanf("%s",&object[i].name);
		
		printf("Enter price of item\n");
		scanf("%f",&object[i].price);
		
		printf("Enter supplier of item\n");
		scanf("%s",&object[i].supplier);
		
		if(object[i].price>max)
		{
			max=object[i].price;
			scanf("%s",&maxsupplier);
		}
		if(object[i].price<min)
		{
			min=object[i].price;
			scanf("%s",&minsupplier);
		}
	}
	
	printf("Most expensive item and supplier: %f/t%s",max,maxsupplier);
	printf("Least expensive item and supplier: %f/t%s",min,minsupplier);
	
	system("Pause");
}
