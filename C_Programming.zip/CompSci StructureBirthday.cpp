#include<stdio.h>
#include<stdlib.h>
#define size 20
main()
{
	struct dateofbirth{
		int day;
		int year;
		char month[size];
	};
	
	dateofbirth birthday;
	
	printf("Enter date of birth: Day, Month, Year\n");
	scanf("%d %s %d",&birthday.day,&birthday.month,&birthday.year);
	printf("Date of Birth:%d/%s/%d\n",birthday.day,birthday.month,birthday.year);
	
	system("Pause");
}
