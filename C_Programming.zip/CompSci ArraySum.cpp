#include<stdio.h>
#include<stdlib.h>
#define size 10
main()
{
	int num[10];//with integers, the null character is not taken into account
	int sum,i;
	sum=0;
	
	for(i=0;i<size;i++)
	{
		printf("Enter a number\n");
		scanf("%d\n",&num[i]);
		sum=sum+num[i];
    } 
     
     printf("The sum is %d\n",sum);
     system("Pause");
	
}
