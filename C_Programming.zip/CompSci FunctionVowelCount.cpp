#include<stdio.h>
#include<stdlib.h>
#define size 8
int VowelCount(char string[])
{
	int i,count=0;

	for(i=0;i<size;i++)
	{
		if ((string[i]=='A')||(string[i]=='E')||(string[i]=='I')||(string[i]=='O')||(string[i]=='U'))
		{
			count=count+1;
		}
	}
	return count;	
}
main()
{
	int cvowel;
	char sentence[size];
	
	printf("Enter a sentence\n");
	scanf("%s",sentence);
	
	cvowel=VowelCount(sentence);
	
	printf("Number of vowels is %d\n",cvowel);

}
