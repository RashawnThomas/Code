#include <stdio.h>
#include <stdlib.h>
main()
{
	int num;
	num=8;

	while(num<100)
	{
		printf("%d\n",num);
		num=num+8;	
	}
	
	system("Pause");
}
