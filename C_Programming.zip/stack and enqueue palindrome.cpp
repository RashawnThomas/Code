#include<stdio.h>
#include<string.h>
#define len 99
int top=-1,index=-1;

char pop(char str[])
{
	char val;
	if(top==-1)
	{
		printf("stack already empty\n");
		
	}
	else
	{
		val=str[top];
		top--;
	}
	return val;
}

void enqueue(char arr[],char let,int size)
{
	
	
	if(index==size)
		printf("queue full\n");
	else
	{
		
		index++;
		
		arr[index]=let;
		

		
	}
}
main()
{
	char string[len],letter,length;
	int i;
	printf("Enter a word\n");
	scanf("%s",&string);
	
	
	length=strlen(string);
	char string2[length+1]={};
	top=length;
	
	for(i=0;i<=length;i++)
	{
		
		letter=pop(string);
		if(letter!='\0')
			enqueue(string2,letter,length);
		
	}

	
	if(stricmp(string,string2)==0)
		printf("This word is a palindrome");
	else
		printf("This word is not a palindrome");
	
}
