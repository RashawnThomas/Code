#include<stdio.h>
#include<stdlib.h>
#include<string.h>

main()
{
	char names[30],term[4]="end",ntemp[15];
	float avg,max=0;
	int Mmark,Emark,Fmark,Gmark;
	FILE* studentmarks;
	
		studentmarks=fopen("Teacher.txt","a");
		if(studentmarks==NULL)
		{
			printf("Error\n");
		}
		else
		{
			printf("Enter the name of the student\n");
			scanf("%s",&names);
			while(strcmp(names,term)!=0)
			{
				printf("Enter Math mark, English mark, French Mark, Geography mark\n");
				scanf("%d%d%d%d",&Mmark,&Emark,&Fmark,&Gmark);
				fprintf(studentmarks,"%s %d %d %d %d\n",names,Mmark,Emark,Fmark,Gmark);
							
				printf("Enter the name of the student\nEnter 'end' to finish");
				scanf("%s",&names);
			}
		}
		fclose(studentmarks);
		
		//Open in read
		studentmarks=fopen("Teacher.txt","r");
		if(studentmarks==NULL)
		{
			printf("Error\n");
		}
		else
		{	
			while(!feof(studentmarks))
			{
				fscanf(studentmarks,"%s %d %d %d %d ",&names,&Mmark,&Emark,&Fmark,&Gmark);
				avg=(Mmark+Emark+Fmark+Gmark)/4;
				if(avg>max)
				{
					max=avg;
					strcpy(ntemp,names);
				}
				printf("\nStudent: %s\n",names);
				printf("Math: %d  English: %d  French:  %d  Geography: %d  Average: %.1f\n",Mmark,Emark,Fmark,Gmark,avg);
				
			}
		}
		fclose(studentmarks);
		printf("\n%s has the highest average of %.1f\n",ntemp,max);
		system("Pause");
}
