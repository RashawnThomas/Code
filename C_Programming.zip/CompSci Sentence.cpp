#include <stdio.h>
#include <stdlib.h>
#include <string.h>
main()
{
	char sentence[50];
	int letters,i;
	
	letters=0;
	
	printf("Enter a sentence\n");
	gets(sentence);
	
	for(i=0;sentence[i]!='\0';i=i+1)//need a for so the loop can go through each section
	{
		if((sentence[i]!=' ') && (sentence[i]!='.') && (sentence[i]!=',') && (sentence[i]!='!') && (sentence[i]!='?'))
		
			letters=letters+1;
		
	}
	//print outside the loop
	
		printf("Number of letters is %d\n",letters);
}
