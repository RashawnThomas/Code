#include<stdio.h>
#include<stdlib.h>
#define size 10
main()
{
	int num[11];
	int sum,i;
	sum=0;
	for(i=0;(i<size);i++)
	{
		printf("Enter a number\n");
		scanf("%d",&num[i]);
	
	
		if((num[i]>20)&&(num[i]<40))
		{
			sum=sum+num[i];
			
		}
	}
	
	printf("Sum of numbers between 20 and 40 is %d\n",sum);
	
	system("Pause");
	
}
