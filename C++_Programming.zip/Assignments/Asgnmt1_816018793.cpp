#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;
const string alphabet = "abcdefghijklmnopqrstuvwxyz";

vector<string> split(const string& s)
{
	vector<string>ret;
	typedef string::size_type string_size;
	string_size i = 0;
	while (i != s.size())
	{
		while (i != s.size() && s[i] == ' ')
			++i;

		string_size j = i;
		while (j != s.size() && s[j] != '!' && s[j] != '.' && s[j] != '-' && s[j] != '\'' && s[j] != ' ')
		{
			++j;
		}

		if (i != j)
		{
			ret.push_back(s.substr(i, j - i));
			j++;
			i = j;
		}
	}
	return ret;
}

class Decode
{

public:
	string en_key;
	string de_key;
	vector<string> encrypted;
	vector<string> decrypted;

	Decode() {
		en_key = "";
		de_key = "";
	}

	void Caesarian(string str)
	{
		int shift = 'Y' - '5';
		string hexa = "";
		char ascii;
		for (int i = 0; i < str.length(); i++)
		{
			hexa += (char)((str[i] + 128 - shift) % 128);
		}
		for (int j = 0; j < hexa.length(); j = j + 2)
		{
			ascii = stoul(hexa.substr(j, 2), nullptr, 16);
			de_key = de_key + ascii;
		}

		cout << de_key << endl;
	}

	void ROT13()
	{
		int shift = 13;
		string hexa = "";
		char ascii;
		for (int i = 0; i < en_key.length(); i++)
		{
			hexa += (char)((en_key[i] + 128 - shift) % 128);
		}
		for (int j = 0; j < hexa.length(); j = j + 2)
		{
			ascii = stoul(hexa.substr(j, 2), nullptr, 16);
			de_key = de_key + ascii;
		}

		cout << de_key << endl;
	}

	void AtBash(string str) {
		const int letterCount = 'z' - 'a' + 1;
		
		for (auto& letter : str) {
			if (!std::isalpha(letter)) {
				continue;
			}
			const bool isUpper = std::isupper(letter);
			const char baseOffset = isUpper ? 'A' : 'a';
			const auto distanceFromAlphabetStart = letter - baseOffset;
			letter = (baseOffset + letterCount - 1) - distanceFromAlphabetStart;
	 		
		}
		std::cout << str;
	}
	
	void Vigenere(string str, string key) {
		string encryptedText = "";
		for (int i = 0, j = 0; i < str.length(); i++) {
			encryptedText += alphabet[(alphabet.find(str[i])
				- alphabet.find(key[j])) % 26];
			j++;
				if (j == key.length()) j = 0;
		}
		cout<< encryptedText;
	}
 
};

int main(){

	Decode manipulate;
	string line, key;
	vector<string> encrypted, decrypted;
	
	ifstream thefile("encrypted.txt");
	if (!thefile)
	{
		cerr << "Cannot open file!";
	}
	getline(thefile, key);
	manipulate.Caesarian(key);

	while (getline(thefile, line))
	{
		encrypted.push_back(line);
	}

	vector<int>::size_type i = 0;
	vector<string> word;

	for (i = 0; i < encrypted.size(); ++i)
	{
		word = split(encrypted[i]);
		for (int j = 0; j < word.size(); ++j)
		{
			decrypted.push_back(word[j]);
		}
	}
	for (string::size_type j = 0; j < decrypted.size(); ++j)
	{
		cout << decrypted[j] << endl;
	}


	return 0;
}