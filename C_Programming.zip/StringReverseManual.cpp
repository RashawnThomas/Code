#include <stdio.h>
#include <stdlib.h>
#include <string.h>
main()
{
	char string1[50],string2[50];
	int i,t;
	
	printf("Enter a string\n");
	gets(string1);
	strcpy(string2,string1);
	t=strlen(string1);
	t=t-1;
	i=0;
	for(t=t;t!=0;t--)
	{
		string2[t]=string1[i];
		i=i+1;
	}
	
	t=0;
	i=strlen(string1);
	i=i-1;
	string2[t]=string1[i];
	printf("%s\n",string2);
	
	if(strcmp(string2,string1)==0)
	{
		printf("The word is a palindrome\n");
	}
	else
	{
		printf("The word is not a palindrome\n");	
	}

	system("Pause");
}
	
