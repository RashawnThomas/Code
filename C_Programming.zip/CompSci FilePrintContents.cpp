#include <stdio.h>
#include <stdlib.h>

main()
{
	char name[50];
	int age;
	FILE* NameNAge; //pointer to file
	
	NameNAge=fopen("FileName&Age.txt","r");
	
	if(NameNAge==NULL)
	{
		printf("Error opening file\n");
	}
	else
	{
		fscanf(NameNAge,"%s%d",&name,&age);//read the record
		while(!feof(NameNAge))//while not the end of file
		{
			printf("Name is %s\n",name);
			printf("Age is %d\n",age);
			fscanf(NameNAge,"%s%d",&name,&age);//read the record
		}
	}
	fclose(NameNAge);
}
