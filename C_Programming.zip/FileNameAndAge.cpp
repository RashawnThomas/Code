#include <stdio.h>
#include <stdlib.h>

main()
{
	char name[50];
	int age,i;
	
	FILE* NameNAge; //pointer to file
	
	NameNAge=fopen("FileName&Age.txt","a");
	
	if(NameNAge==NULL)
	{
		printf("Error opening file\n");
	}
	else
	{
		for(i=0;i<5;i++)
		{
			printf("Enter a name and an age\n");
			scanf("%s%d",&name,&age);
			fprintf(NameNAge,"%s%d\n",name,age);	
		}
	}
	
	fclose(NameNAge);
}


