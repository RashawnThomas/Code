#include <stdio.h>
#include <stdlib.h>
#define size 10

void swap(int array[],int num1,int num2)
{
	int i;
	
	i=array[num1];
	array[num1]=array[num2];
	array[num2]=i;
}
main()
{
	int x,pos1,pos2,hole[size];
	
	printf("Enter 10 numbers\n");
	
	for(x=0;x<size;x++)
	{
		scanf("%d",&hole[x]);
	}
	for(x=0;x<size;x++)
	{
		printf("Old  format: %d\n",hole[x]);
	}

	printf("Enter 2 positions to swap\n");
	scanf("%d%d",&pos1,&pos2);
	swap(hole,pos1,pos2);
	
	for(x=0;x<size;x++)
	{
		printf("New Format: %d\n",hole[x]);	
	}
	
}
