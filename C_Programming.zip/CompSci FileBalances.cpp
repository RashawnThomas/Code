#include<stdio.h>
#include<stdlib.h>
main()
{
	FILE* F1;
	int customers=0,id,books;
	float overfees,Pfees=0,Nfees=0,totalfees=0,maxfee=0;
	char rate;
	
	F1=fopen("Balances.txt","r");
	if(F1==NULL)
	{
		printf("Error");
	}
	else
	{
		fscanf(F1,"%d",&id);
		while(id!=9999)
		{
			fscanf(F1,"%d %c",&books, &rate);
			if(rate=='P')
			{
				overfees=6.50*books;
				Nfees=Nfees+overfees;
				totalfees=totalfees+overfees;
				customers++;
				printf("The total outstanding fees for %d: %.2f\n",id,overfees);
				if(overfees>maxfee)
				{
					maxfee=overfees;
				}
			}
			if(rate=='N')
			{
				overfees=4.50*books;
				Pfees=Pfees+overfees;
				totalfees=totalfees+overfees;
				customers++;
				printf("The total outstanding fees for %d: %.2f\n",id,overfees);
				if(overfees>maxfee)
				{
					maxfee=overfees;
				}
			}
			fscanf(F1,"%d",&id);
		}
	}
		printf("Customer Fee: %.2f\n",overfees);
		printf("Category N fees: %.2f\tCategory P fees: %.2f\n",Nfees,Pfees);
		printf("Total Fees: %.2f\n",totalfees);
		printf("No. of Customers: %d\n",customers);
		printf("Highest Fee: %.2f",maxfee);
		
		fclose(F1);
}
