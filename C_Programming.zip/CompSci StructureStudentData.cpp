#include<stdio.h>
#include<stdlib.h>
#define size 30
main()
{
	struct info{
		int id;
		int coursecode[10];
		float percentage[10];
		char name[50];
	};
	
	struct info studentdata[size];
	int i,x,z,y=0,failed=0,searchcode;
	float avgpercent[10],totalpercent=0;
	
	
	for(i=0;i<size;i++)
	{
		for(x=0;x<10;x++)
		printf("Enter the student's name\n");
		scanf("%s",&studentdata[i].name);
		
		printf("Enter student's id\n");
		scanf("%d",studentdata[i].id);
		
		printf("Enter the student's course\n");
		scanf("%d",studentdata[i].coursecode[x]);
		
		printf("Enter the percentage of that course\n");
		scanf("%f",studentdata[i].percentage[x]);
		
		totalpercent=totalpercent+studentdata[i].percentage[x];
		avgpercent[i]=totalpercent/10;
		printf("Average percentage for %s is %.2f",studentdata[i].name,avgpercent[i]);
		
		if(avgpercent[i]<50)
		{
			failed=failed+1;
		}
	}
	
	printf("Amount of failed students: %d",failed);
	
	printf("Search for a student's average percentage; Enter their course code\n");
	scanf("%d",&searchcode);
	for(z=0;z<size;z++)
	{
		while(y<10)
		if(searchcode==studentdata[z].coursecode[y])
		{
			printf("Student's average percentage is %.2f",studentdata[z].percentage[y]);
		}	
	}
}
