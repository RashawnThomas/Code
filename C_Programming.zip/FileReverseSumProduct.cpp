#include<stdio.h>
#include<stdlib.h>

main()
{
	FILE* F1;
	int a,b,sum,product;

	F1=fopen("in.dat.txt","r");
	if(F1==NULL)
	{
		printf("Error\n");
	}
	else
	{
		fscanf(F1,"%d %d",&a,&b);
		printf("%d %d\n",b,a);
	
		sum=a+b;
		product=a*b;
	
		printf("Sum:%d\t Product:%d",sum,product);
	}
	fclose(F1);
}
