/* write a program that reads ten numbers entered by the user using, either a bubble or selsection sort sort the elements in descending order. Print the ccontent of the sorted array along with the index
 values. Promt the user to enter a value of their choice and print the index location of the element if not found print an error message to say so. */
 #include <stdio.h>
 #include <stdlib.h>
 #define length 10
 
 int main()
 {
 	int last,mid,found,findme,first,temp,index,i,j,elem;
 	int num[length];
 	
 	first=0;
 	last=(length-1);
 	found=0;
 	
 	mid=(last+first)/2;
 	
 	printf("Enter 10 number\n");
 	for(i=0;i<length;i++)
 	{
		 scanf(" %d",&num[i]);
	}
	
	for(i=0;i<length-1;i++)
	{
		index=i;
		
		for(j=(i+1);j<length;j++)
		{
			if(num[j]>num[index])
				index=j;
		}
		
		temp=num[index];
		num[index]=num[i];
		num[i]=temp;
		
	}
	
	for(i=0;i<length;i++)
	{
		printf("value : %d \n",num[i]);
	}
	
	printf("Enter the number you wish to find\n");
	scanf("%d",&findme);
	
	while((last>=first) && (found!=1))
	{
		//printf("The mid point is %d\n",mid);
		
		if(findme==num[mid])
			found=1;
			
		if(findme>num[mid])
		{
				last=mid-1;
					mid=(first+last)/2;
		}
		
			
		else if(findme<num[mid])
		{
			first=mid+1;
				mid=(first+last)/2;
		}
		
		mid=(first+last)/2;
	}
	
	if(found==1)
		printf("%d is found at position %d",findme,mid);
		
	else
		printf("Number not found");

 }
