#include <iostream> 
#include <fstream>	
#include <string>	
#include <vector>
#include <locale>	
#include <chrono>
#include <iomanip>
#include <iterator>

const int size = 256;

using std::ifstream;	using std::vector;		using std::ofstream;
using std::cout;		using std::string;		using std::isalnum;
using std::endl;		using std::getline;		using std::cin;



//--------------------------------------------------------------CLASSES-------------------------------------------------------------------//



class Timer {
public:
	std::chrono::time_point<std::chrono::steady_clock> start, end;
	std::chrono::duration<float> duration;

	Timer();
	~Timer();
};



class stack {
private:
	string* bottom;
	string* top;
	int size;
public:
	stack(int size = 256);
	void push(string val);
	void pop();
	int num_items() const;
	int full() const;
	int empty() const;
	void print() const;
	string topElement() const;
	~stack();
};


class Queue
{
private:
	string A[size];
	int front, rear;
public:
	Queue();
	bool IsEmpty();
	bool IsFull(); 
	void Enqueue(string x);
	void Dequeue(); 
	string Front();
	void Print();
	int num_elements() const;
};


//-------------------------------------------------------------FUNCTIONS------------------------------------------------------------------//


bool isalphanum(string& data)
{
	{
		for (string::size_type i = 0; i != data.size(); i++) {
			if (isalnum(data[i]) == false) {
				return false;
			}
		}
		return true;
	}
}

string fix(string& data)
{
	char c;
	for (string::size_type i = 0; i != data.size(); i++) {
		if (isalnum(data[i]) == false) {
			cout << "Error Found. Enter alphanumeric character." << endl;
			cin >> c;
			data[i] = c;
		}
	}
	cout << "Corrected packet is now " << data << endl;
	return data;
}


void swap(string* xp, string* yp)
{
	string temp = *xp;
	*xp = *yp;
	*yp = temp;
}

vector<string> bubblesort(vector<string> vec, int n)
{
	Timer time;
	int i, j;
	bool swapped;
	for (i = 0; i < n - 1; i++)
	{
		swapped = false;
		for (j = 0; j < n - i - 1; j++)
		{
			if (vec[j] > vec[j + 1])
			{
				swap(&vec[j], &vec[j + 1]);
				swapped = true;
			}
		}
		// IF no two elements were swapped by inner loop, then break
		if (swapped == false)
			break;
	}
	return vec;
}

vector<string> selectsort(vector<string> vec, int n)
{
	Timer time;
	//pos_min is short for position of min
	int pos_min;
	string temp;
	for (int i = 0; i < n - 1; i++)
	{
		pos_min = i;//set pos_min to the current index of array
		for (int j = i + 1; j < n; j++)
		{
			if (vec[j] < vec[pos_min])
				pos_min = j;
			//pos_min will keep track of the index that min is in, this is
			//needed when a swap happens
		}
		//if pos_min no longer equals i than a smaller value must have been found,
		//so a swap must occur
		if (pos_min != i)
		{
			temp = vec[i];
			vec[i] = vec[pos_min];
			vec[pos_min] = temp;
		}
	}
	return vec;
}

vector<string> insertion_sort(vector<string> vec, int length)
{
	Timer time;
	int j;
	string temp;
	for (int i = 0; i < length; i++) {
		j = i;
		while (j > 0 && vec[j] < vec[j - 1]) {
			temp = vec[j];
			vec[j] = vec[j - 1];
			vec[j - 1] = temp;
			j--;
		}
	}
	return vec;
}



//--------------------------------------------------------------MAIN----------------------------------------------------------------------//



int main() {

	
	string packet;
	stack package;

	ifstream myfile("input data.txt");
	if (!myfile) {
		cout << "File not found" << endl;
	}
	else {
		while (getline(myfile, packet)) {
			if (package.num_items() < size) {
				if (isalphanum(packet) != false) {
					package.push(packet);
				}
				else {
					packet = fix(packet);
					package.push(packet);
				}
			}
			else {
				break;
			}
		}
	}

	vector<string> block, bubble_vec, select_vec, insert_vec;
	ofstream afile("solution1.txt");
	while (package.empty() != 1) {
		afile << package.topElement() << endl;
		block.push_back(package.topElement());
		package.pop();
	}


	std::cout << std::fixed;
	std::cout << std::setprecision(3);



	//BUBBLE SORT TIME
	cout << "Bubble Sort Time: " << endl;
	bubble_vec = bubblesort(block, size);
	cout << endl;
	//SELECTION SORT TIE
	cout << "Selection Sort Time: " << endl;
	select_vec = selectsort(block, size);
	cout << endl;
	//INSERTION SORT
	cout << "Insertion Sort Time: " << endl;
	insert_vec = insertion_sort(block, size);

	//Selection sort is the fastest
	ofstream sortfile("solution2.txt");
	sortfile << "Optimized Package using Selection Sort: " << endl;
	std::ostream_iterator<std::string> output_iterator(sortfile, "\n");
	std::copy(select_vec.begin(), select_vec.end(), output_iterator);


	stack server;
	for (vector<string>::iterator i = select_vec.begin(); i < select_vec.end(); i++) {
		server.push(*i);
	}
	Queue client, transmission;
	ofstream dqfile("solution3.txt");
	while (server.empty() != 1) {
		transmission.Enqueue(server.topElement());
		server.pop();
		if (transmission.num_elements() >= 8) {
			client.Enqueue(transmission.Front());
			dqfile << transmission.Front() << endl;
			transmission.Dequeue();
		}
	}
	return 0;
}





	


//------------------------------------------------------------DEFINITIONS-----------------------------------------------------------------//


stack::stack(int N)
{
	bottom = new string[N];
	top = bottom;
	size = N;
}

void stack::push(string val)
{
	*top = val;
	top++;
}

int stack::num_items() const
{
	return (top - bottom);
}

void stack::pop()
{
	top--;
}

int stack::full() const
{
	return (num_items() >= size);
}

int stack::empty() const
{
	return (num_items() <= 0);
}

void stack::print() const
{
	std::cout << "Stack currently holds " << num_items() << " items: ";
	for (string* element = bottom; element < top; element++) {
		std::cout << " " << *element;
	}
	std::cout << "\n";
}

string stack::topElement() const
{
	return *(top-1);

}

stack::~stack()
{
	delete[] bottom;
}

Timer::Timer()
{
	 start = std::chrono::high_resolution_clock::now();
	 end = start;
	 duration = end - start;
}

Timer::~Timer()
{
	 end = std::chrono::high_resolution_clock::now();
	 duration = end - start;
	 float millisec = duration.count() * 1000.0f;
	 cout << "Time elasped = " << millisec << " ms" << endl;
}

Queue::Queue()
{
	front = -1;
	rear = -1;
}

bool Queue::IsEmpty()
{
	return (front == -1 && rear == -1);
}

bool Queue::IsFull()
{
	if ((rear + 1) % size == front) {
		return true;
	}
	else {
		return false;
	}
}

void Queue::Enqueue(string x)
{
	std::cout << "Enqueuing " << x << " \n";
	if (IsFull())
	{
		std::cout << "Error: Queue is Full\n";
		return;
	}
	if (IsEmpty())
	{
		front = rear = 0;
	}
	else
	{
		rear = (rear + 1) % size;
	}
	A[rear] = x;
}

void Queue::Dequeue()
{
	std::cout << "Dequeuing \n";
	if (IsEmpty())
	{
		std::cout << "Error: Queue is Empty\n";
		return;
	}
	else if (front == rear)
	{
		rear = front = -1;
	}
	else
	{
		front = (front + 1) % size;
	}
}

string Queue::Front()
{
	if (front == -1)
	{
		return "Error: cannot return front from empty queue\n";
	}
	return A[front];
}

void Queue::Print()
{
	// Finding number of elements in queue  
	int count = (rear + size - front) % size + 1;
	std::cout << "Queue       : ";
	for (int i = 0; i < count; i++)
	{
		int index = (front + i) % size; // Index of element while
		//travesing circularly from front
		std::cout << A[index] << " ";
	}
	std::cout << "\n\n";
}

int Queue::num_elements() const
{
	return (rear-front);
}
