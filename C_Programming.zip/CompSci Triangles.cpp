#include<stdio.h>
#include<stdlib.h>
main()
{
	int a,b,c;
	
	printf("Enter 3 values\n");
	scanf("%d%d%d",&a,&b,&c);
	
	if((a<=0)||(c<=0)||(b<=0))
	{
		printf("Invalid\n");
	}
	else if((a==b)&&(a==c)&&(b==c))
	{
		printf("The triangle is an equilateral\n");
	}
	else if((a==b)||(a==c)||(b==c))
	{
		printf("The triangle is an isoceles\n");
	}
	else if(a!=b!=c)
	{
		printf("The triangle is a scalene\n");
	}
	
	
	system("Pause");
}
