#include <iostream>
#include <vector>
#include <list>
#include <fstream>
#include <string>
#include <chrono>
#include <utility>
#include <unordered_map>
#include <sstream>
#include <iomanip>

using std::cout;		using std::vector;			using std::chrono::high_resolution_clock;			using std::unordered_map;
using std::cerr;		using std::list;			using std::chrono::duration_cast;					using std::pair;
using std::cin;			using std::ofstream;		using std::chrono::milliseconds;							using std::stringstream;
using std::endl;		using std::ifstream;		using std::fixed;
						using std::string;			using std::setprecision;

class A3Graph {
private:

	struct node {
		vector<pair<char,string>> toNode;
		vector<pair<char, string>> fromNode;
		vector<pair<char, string>> fullstops;
	};

	unordered_map<string, node> graph;
	vector<string> char_stream;
	string first_word = "", previous_word = "", present_word = "";
	bool getFirst = false;
	char char_edge = '\0', char_end = '\0';
	int first_word_index = 0;


	void readinFile(ifstream& inputFilePointer) { 
		string tmp_string = "";

		inputFilePointer.seekg(0);
		while (inputFilePointer >> tmp_string) {
			char_stream.push_back(tmp_string);
		}
	}

	void connectEdgeIn(string from, string to, char edge) { //connects edge to node
		pair<char, string> tmpEdge(edge, to);
		bool alreadyExists = false;

		if (graph.find(to) != graph.end()) {
			if (edge == '.') {
				for (int j = 0; j < graph[to].fullstops.size(); j++) {
					if (graph[to].fullstops[j].second == tmpEdge.second) {
						alreadyExists = true;
						break;
					}
				}
			}
			else {
				for (int j = 0; j < graph[to].toNode.size(); j++) {
					if (graph[to].toNode[j].second == tmpEdge.second) {
						alreadyExists = true;
						break;
					}
				}
			}

			if (!alreadyExists) {
				if (edge == '.')
					graph[to].fullstops.push_back(tmpEdge);
				else
					graph[to].toNode.push_back(tmpEdge);
			}
		}
		else if (graph.find(to) == graph.end()) {
			node tmpTo;

			if (edge == '.')
				tmpTo.fullstops.push_back(tmpEdge);
			else
				tmpTo.toNode.push_back(tmpEdge);

			graph[to] = tmpTo;
		}
	}

	void connectEdgeOut(string from, string to, char edge) { //connects edge from node
		pair<char,string> tmpEdge(edge, to);
		bool alreadyExists = false;

		if (graph.find(from) != graph.end()) {
			if (edge == '.') {
				for (int j = 0; j < graph[from].fullstops.size(); j++) {
					if (graph[from].fullstops[j].second == tmpEdge.second) {
						alreadyExists = true;
						break;
					}
				}
			}
			else {
				for (int j = 0; j < graph[from].fromNode.size(); j++) {
					if (graph[from].fromNode[j].second == tmpEdge.second) {
						alreadyExists = true;
						break;
					}
				}
			}

			if (!alreadyExists) {
				if (edge == '.')
					graph[from].fullstops.push_back(tmpEdge);
				else
					graph[from].fromNode.push_back(tmpEdge);
			}
		}
		else if (graph.find(from) == graph.end()) {
			node tmpFrom;

			if (edge == '.')
				tmpFrom.fullstops.push_back(tmpEdge);
			else
				tmpFrom.fromNode.push_back(tmpEdge);

			graph[from] = tmpFrom;
		}
	}

	void locateStart() {
		string tmp_string = "";

		for (int i = 0; i < char_stream.size(); i++) {
			tmp_string = char_stream[i];

			if (tmp_string[tmp_string.size() - 1] == '.')
				continue;
			else {
				if (tmp_string[tmp_string.size() - 1] == ',') {
					char_edge = ',';
					first_word = tmp_string.substr(0, tmp_string.size() - 1);
					first_word_index = i;
					previous_word = first_word;
					break;
				}
				else {
					char_edge = '\0';
					first_word = tmp_string;
					first_word_index = i;
					previous_word = first_word;
					break;
				}
			}
		}

	}

	void buildGraph() {
		string tmp_string = "";

		locateStart();

		for (int i = first_word_index + 1; i < char_stream.size(); i++) {

			tmp_string = char_stream[i];

			if (tmp_string[tmp_string.size() - 1] == '.') {
				present_word = tmp_string.substr(0, tmp_string.size() - 1);
				char_end = '.';
			}
			else if (tmp_string[tmp_string.size() - 1] == ',') {
				present_word = tmp_string.substr(0, tmp_string.size() - 1);
				char_end = ',';
			}
			else {
				present_word = tmp_string;
				char_end = '\0';
			}

			connectEdgeOut(previous_word, present_word, char_edge);
			connectEdgeIn(previous_word, present_word, char_edge);

			previous_word = present_word;
			present_word = "";
			char_edge = char_end;
			char_end = '\0';
		}

		cout << "Graph completed" << endl;

		cout << "Graph has " << graph.size() << "node(s)" << endl << endl;
		
	}

	void commanateEdgeIn(string from, string to) { // commanates edges into the node
		for (int i = 0; i < graph[to].toNode.size(); i++) {
			if (graph[to].toNode[i].second == from) {
				graph[to].toNode[i].first = ',';
				break;
			}
		}
	}

	void commanateEdgeOut(string from, string to) { // commanates edges from the node
		for (int i = 0; i < graph[from].fromNode.size(); i++) {
			if (graph[from].fromNode[i].second == to) {
				graph[from].fromNode[i].first = ',';
				break;
			}
		}
	}
	
	void holdNext(string node, list<string>* queue, unordered_map<string, bool>* visited) { //holds next node to be commanated
		for (int j = 0; j < graph[node].fromNode.size(); j++) {
			string tmp = graph[node].fromNode[j].second;
			if ((*visited)[tmp] == false) {
				queue->push_back(tmp);
				(*visited)[tmp] = true;
			}
		}

		for (int j = 0; j < graph[node].toNode.size(); j++) {
			string tmp = graph[node].toNode[j].second;
			if ((*visited)[tmp] == false) {
				queue->push_back(tmp);
				(*visited)[tmp] = true;
			}
		}

		for (int j = 0; j < graph[node].fullstops.size(); j++) {
			string tmp = graph[node].fullstops[j].second;
			if ((*visited)[tmp] == false) {
				queue->push_back(tmp);
				(*visited)[tmp] = true;
			}
		}
	}

	bool commanateGraph() {  //runs through graph and commanates it
		int commanateCounter = 0;
		string node = "";

		unordered_map<string, bool> visited;
		for (auto x : graph) {
			visited[x.first] = false;
		}

		list<string> queue;              

		visited[first_word] = true;
		queue.push_back(first_word);

		while (!queue.empty()) {
			bool commaAfter = false, commaBefore = false;
			bool incomingEdgesCommanated = true, outgoingEdgesCommanated = true;
			int commanateCheck = 0;

			node = queue.front();
			queue.pop_front();


			if (graph[node].fromNode.size() != 0) {
				char outgoingEdgeTmp = graph[node].fromNode[0].first;
				for (int j = 1; j < graph[node].fromNode.size(); j++) {
					if (graph[node].fromNode[j].first != outgoingEdgeTmp) {
						outgoingEdgesCommanated = false;
						break;
					}
				}
			}

			if (graph[node].toNode.size() != 0) {
				char incomingEdgeTmp = graph[node].toNode[0].first;
				for (int j = 1; j < graph[node].toNode.size(); j++) {
					if (graph[node].toNode[j].first != incomingEdgeTmp) {
						incomingEdgesCommanated = false;
						break;
					}
				}
			}

			if (incomingEdgesCommanated && outgoingEdgesCommanated) {
				holdNext(node, &queue, &visited);
				continue;
			}

			for (int j = 0; j < graph[node].toNode.size(); j++) {
				if (graph[node].toNode[j].first == ',') {
					commaBefore = true;
					commanateCheck++;
					break;
				}
			}

			if (commaBefore) {
				for (int j = 0; j < graph[node].toNode.size(); j++) {
					graph[node].toNode[j].first = ',';
					commanateEdgeOut(graph[node].toNode[j].second, node);
				}
			}

			for (int j = 0; j < graph[node].fromNode.size(); j++) {
				if (graph[node].fromNode[j].first == ',') {
					commaAfter = true;
					commanateCheck++;
					break;
				}
			}

			if (commaAfter) {
				for (int j = 0; j < graph[node].fromNode.size(); j++) {
					graph[node].fromNode[j].first = ',';
					commanateEdgeIn(node, graph[node].fromNode[j].second);
				}
			}

			if (commanateCheck == 1 || commanateCheck == 2)
				commanateCounter++;

			holdNext(node, &queue, &visited);

		}


		if (commanateCounter == 0)
			return true;

		return false;
	}


public:
	A3Graph(ifstream& inputFile) {

		readinFile(inputFile);
		buildGraph();

	}

	void commanate() {
		int num_traversal = 0;
		do {
			num_traversal++;
		} while (commanateGraph() == false);
		cout << "Number of traversals: " << num_traversal << endl;
	}

	void outputCommanatedFile(ofstream& outputFilePointer) {
		string tmp_string = "";
		stringstream ss;

		outputFilePointer.seekp(0);

		for (int i = 0; i < char_stream.size(); i++) {
			tmp_string = char_stream[i];

			if (tmp_string[tmp_string.size() - 1] == '.' || tmp_string[tmp_string.size() - 1] == ',') {
				tmp_string.append(1, ' ');
				ss << tmp_string;
			}
			else {
				if (graph[tmp_string].fromNode[0].first == ',')
					tmp_string.append(1, ',');
				tmp_string.append(1, ' ');
				ss << tmp_string;
			}
		}
		outputFilePointer << ss.str();
	}


};

int main() {

	auto startTime = high_resolution_clock::now();

	string test_cases[8] = { "tc-1.in", "tc-2.in", "tc-3.in", "tc-4.in", "tc-5.in", "tc-6.in", "tc-7.in", "tc-8.in" };						
	string test_caseANS[8] = {  "tc-1.ans", "tc-2.ans", "tc-3.ans", "tc-4.ans", "tc-5.ans", "tc-6.ans", "tc-7.ans", "tc-8.ans" };						
	string results[8] = { "result1.txt", "result2.txt", "result3.txt", "result4.txt", "result5.txt", "result6.txt", "result7.txt", "result8.txt" };
								

	for (int FileIndex = 0; FileIndex < 8; FileIndex++) {
		if (FileIndex != 0) {
			cout << "__________________________________________________________________________________________" << endl << endl;
		}

		ifstream pointIn_File(test_cases[FileIndex]);
		if (!pointIn_File) {
			cerr << "Could not open file: " << test_cases[FileIndex] << endl;
			return 1;
		}

		ifstream pointOut_expFile(test_caseANS[FileIndex]);
		if (!pointOut_expFile) {
			cerr << "Could not open file: " << test_caseANS[FileIndex] << endl;
			return 1;
		}

		ofstream pointOut_File(results[FileIndex]);
		if (!pointOut_File) {
			cerr << "Could not open file: " << results[FileIndex] << endl;
			return 1;
		}

		cout << "Input file: " << test_cases[FileIndex] << endl << endl;

		A3Graph commaGraph(pointIn_File);
		pointIn_File.close();

		cout << "Creating Commanated Graph ..." << endl;

		auto start = high_resolution_clock::now();
		commaGraph.commanate();
		auto end = high_resolution_clock::now();
		int duration = duration_cast<milliseconds>(end - start).count();

		cout << "Commanation completed" << endl;
		cout << "Time Taken: " << fixed << setprecision(2) << ((float)duration) << "ms" << endl << endl;


		start = high_resolution_clock::now();
		commaGraph.outputCommanatedFile( pointOut_File);
		end = high_resolution_clock::now();
		int result_time = duration_cast<milliseconds>(end - start).count();

		cout << "Output file generated" << endl;
		cout << "Time Taken: " << fixed << setprecision(2) << ((float)result_time) << "ms" << endl << endl;
		cout << "Net Time: " << fixed << setprecision(2) << ((float)duration + result_time) << "ms" << endl << endl;

		// compare output and expected output
		pointOut_File.close();
		ifstream readoutFile(results[FileIndex]);
		if (!readoutFile) {
			cerr << "Could not open file: " << results[FileIndex] << endl;
			return 1;
		}

		end = high_resolution_clock::now();
		int runtime = duration_cast<milliseconds>(end - startTime).count();

		cout << "Total Runtime: " << fixed << setprecision(2) << ((float)runtime) << "ms" << endl << endl;

		
		pointOut_expFile.close();
		pointOut_File.close();
	}

	return 0;
}