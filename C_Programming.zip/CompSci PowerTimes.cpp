#include<stdio.h>
#include<stdlib.h>
#define base 2
main()
{
	int x=1,p,i;
	
	printf("Enter a power\n");
	scanf("%d",&p);
	
	for(i=1;i<=p;i++)
	{
		x=x*base;
	}
	printf("%d\n",x);
	system("Pause");
}
