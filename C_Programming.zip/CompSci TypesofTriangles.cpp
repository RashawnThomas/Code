#include<stdio.h>
#include<stdlib.h>
main()
{
	int a,b,c;
	
	printf("Enter the length of the sides of the triangle\n");
	scanf("%d %d %d",&a,&b,&c);
	if((a>(b+c))||(b>(a+c))||(c>(a+b))||(a<=0)||(c<=0)||(b<=0))
	{
		printf("No triangle is represented\n");
	}
	else if((a==b)&&(a==c)&&(b==c))
	{
		printf("The triangle is an equilateral triangle\n");
	}
	else if((a==b)||(a==c)||(b==c))
	{
		printf("The triangle is an isosceles triangle\n");
	}
	else if((a!=b)&&(a!=c)&&(b!=c))
	{
		printf("The triangle is a scalene triangle\n");
	}
	
		system("Pause");
}
