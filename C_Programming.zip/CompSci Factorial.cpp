#include<stdio.h>
#include<stdlib.h>
int factorial(int num)
{
		int i,fact=1;
		
		for(i=num;i>=1;i--)
		{
			fact=fact*i;
		}
	return fact;
}
main()
{
	
	int numba,result;
	printf("Enter a number\n");
	scanf("%d",&numba);
	
	result=factorial(numba);
	printf("Factorial of %d is %d\n",numba,result);
	
}
