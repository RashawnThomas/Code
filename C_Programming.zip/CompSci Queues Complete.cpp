#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#define length 11

int tail=-1;

void enqueue(char queue[],char element)
{
	
	if (tail==(length-1))//check if queue is full
	{
		printf("Queue is full\n");
		system("Pause");
	}
	else
	{	
		tail++;	
		queue[tail]=element;
			
	}
}

char dequeue(char queue[])
{
	int i,element;
	if (tail==-1) 
	{
		printf("Queue is empty\n");
	}
	else
	{
		element=queue[0];//make element the head 
		for(i=0;i<tail;i++)
		{
			queue[i]=queue[i+1];
		}
	}
	tail=tail-1;
	return element;
	
}

bool isempty(char queue[])
{
	if (tail==-1)//check if queue is empty
	{
		return true;
	}
	else
	{		
		return false;
	}
}

int size(char queue[])
{
	if (tail==-1) 
	{
		return 0;
	}
	else
	{
		return (tail+1);
	}
}

void printAll(char queue[])
{
	int i;
	
	if (tail==-1) 
	{
		printf("Queue is empty\n");
	}
	else
	{
		printf("The elements are \n\n");
		for(i=0;i<=tail;i++)
		{
			printf("%c\n",queue[i]);
		}
	}
}

main()
{
	char string[length],letter,character,truth[5]="true",wrong[6]="false"; 
	int amount,i,remove;
	
	for(i=0;i<length-1;i++)
	{
		printf("Enter a character\n");
		scanf("%c",&letter);
		getchar();
		enqueue(string,letter);
	}
	
	amount=size(string);
	printf("The number of elements is %d\n",amount);
	printAll(string);
	
	printf("How many characters to remove?\n");
	scanf("%d",&remove);
	for(i=1;i<=remove;i++)
	{
		dequeue(string);
	}
	
	amount=size(string);
	printf("The number of elements is %d\n",amount);
	printAll(string);
	
	printf("Enter a character\n");
	
	while(tail<(length-2))
	{
		scanf(" %c",&character);
		getchar();
		enqueue(string,character);
		printf("Enter a character\n");
	}
	
	if(tail=(length-2))
		{
			printf("Queue is full\n");
		}
		
	amount=size(string);
	printf("The number of elements is %d\n",amount);
	printAll(string);
		
	system("Pause");
}
