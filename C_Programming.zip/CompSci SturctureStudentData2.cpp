#include<stdio.h>
#include<stdlib.h>
#define size 2
#define amount 2
main()
{
	struct info{
		int id;
		int coursecode[amount];
		float percentage[amount];
		float avgpercent;
		char name[50];
	};
	
	struct info studentdata[size];
	int i,x,z,y=0,failed=0,searchcode;
	float totalpercent;
	
	
	for(i=0;i<size;i++)
	{
		
			printf("Enter the student's name\n");
			scanf("%s",&studentdata[i].name);
		
			printf("Enter student's id\n");
			scanf("%d",&studentdata[i].id);
			
		totalpercent=0;
		for(x=0;x<amount;x++)
		{
			printf("Enter the subject's coursecode\n");
			scanf("%d",&studentdata[i].coursecode[x]);
		
			printf("Enter the percentage for that course\n");
			scanf("%f",&studentdata[i].percentage[x]);
		
			totalpercent=totalpercent+studentdata[i].percentage[x];
			studentdata[i].avgpercent=totalpercent/amount;
		}
			printf("Average percentage for %s is %.2f\n",studentdata[i].name,studentdata[i].avgpercent);
		
			if(studentdata[i].avgpercent<50)
			{
				failed=failed+1;
			}
			
	}
	
	printf("Amount of failed students: %d\n",failed);
	
	printf("Search for students' average percentage; Enter their coursecode\n");
	scanf("%d",&searchcode);
	z=0;
	for(z=0;z<size;z++)
	{
		for(y=0;y<amount;y++)
			if(searchcode==studentdata[z].coursecode[y])
			{
				printf("Student: %s\t Average Percentage: %.2f\n",studentdata[z].name,studentdata[z].avgpercent);
			}	
	}
	system("Pause");
}
