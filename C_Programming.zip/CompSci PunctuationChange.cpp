#include<stdio.h>
#include<stdlib.h>
#include<string.h>
main()
{
	char sentence[50];
	int i;
	
	printf("Enter a sentence\n");
	gets(sentence);
	
	for (i=0;sentence[i]!='\0';i++)
	{
		if ( (sentence[i]=='.')||(sentence[i]=='"')||(sentence[i]=='!')||(sentence[i]==',') )
		
			sentence[i]='*';
		
	}
	
	puts(sentence);
	
}

